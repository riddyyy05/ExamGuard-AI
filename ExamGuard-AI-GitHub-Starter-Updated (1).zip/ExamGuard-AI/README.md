# ExamGuard AI

AI-assisted, privacy-conscious examination monitoring prototype.

## What this prototype does
- Reads a video file or camera feed.
- Detects people using a pretrained YOLO model.
- Maps detections to manually configured seat zones.
- Logs basic position-change events with timestamps for human review.

## Important limitations
This is an experimental demonstration, not a reliable cheating detector. Movement can have many innocent explanations. Alerts are not proof of misconduct and must never trigger automatic penalties. Use only consented, synthetic, or otherwise authorised footage. Do not commit identifiable student footage or personal data.

## Setup
1. Install Python 3.10 or newer.
2. Create and activate a virtual environment.
3. Install dependencies:

   ```bash
   pip install -r requirements.txt
   ```

4. Place an authorised test video at `data/sample_videos/sample_exam.mp4`, or update the video path in `src/main.py`.
5. Run:

   ```bash
   python src/main.py
   ```

The first run may download the YOLO model weights. Model weights and generated CSV reports are excluded from Git by `.gitignore`.

## Project structure
```text
ExamGuard-AI/
├── README.md
├── requirements.txt
├── .gitignore
├── src/
│   └── main.py
├── data/
│   └── sample_videos/
├── reports/
└── screenshots/
```
