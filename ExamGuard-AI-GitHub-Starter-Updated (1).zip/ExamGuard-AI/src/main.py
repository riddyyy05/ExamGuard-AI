"""Basic ExamGuard AI demonstration.

Detects people and logs large position changes within manually defined seat zones.
This is NOT a cheating detector. Use only authorised test footage.
"""
from pathlib import Path
import csv
import time
from datetime import datetime

import cv2
from ultralytics import YOLO

ROOT = Path(__file__).resolve().parents[1]
VIDEO_PATH = ROOT / "data" / "sample_videos" / "sample_exam.mp4"
REPORT_PATH = ROOT / "reports" / "event_log.csv"
MODEL_NAME = "yolov8n.pt"

# Example seat zones: (x1, y1, x2, y2). Adjust for your test video.
SEAT_ZONES = {
    "Seat-A": (0, 0, 320, 480),
    "Seat-B": (321, 0, 640, 480),
}
MOVEMENT_THRESHOLD_PX = 60
ALERT_COOLDOWN_SECONDS = 5


def centre(box):
    x1, y1, x2, y2 = map(int, box)
    return ((x1 + x2) // 2, (y1 + y2) // 2)


def find_zone(point):
    x, y = point
    for seat, (x1, y1, x2, y2) in SEAT_ZONES.items():
        if x1 <= x <= x2 and y1 <= y <= y2:
            return seat
    return "Unassigned"


def main():
    if not VIDEO_PATH.exists():
        raise FileNotFoundError(
            f"Add an authorised test video at: {VIDEO_PATH}"
        )

    model = YOLO(MODEL_NAME)
    cap = cv2.VideoCapture(str(VIDEO_PATH))
    if not cap.isOpened():
        raise RuntimeError("Could not open the input video.")

    REPORT_PATH.parent.mkdir(parents=True, exist_ok=True)
    previous_positions = {}
    last_alert = {}

    with REPORT_PATH.open("w", newline="", encoding="utf-8") as report:
        writer = csv.writer(report)
        writer.writerow(["timestamp", "seat_zone", "event", "review_note"])

        while True:
            ok, frame = cap.read()
            if not ok:
                break

            results = model.track(frame, persist=True, classes=[0], verbose=False)
            now = time.time()

            for result in results:
                if result.boxes is None:
                    continue
                for box in result.boxes:
                    if box.id is None:
                        continue

                    track_id = int(box.id[0])
                    point = centre(box.xyxy[0].tolist())
                    zone = find_zone(point)

                    if track_id in previous_positions:
                        old_x, old_y = previous_positions[track_id]
                        distance = ((point[0] - old_x) ** 2 +
                                    (point[1] - old_y) ** 2) ** 0.5
                        cooldown_ok = now - last_alert.get(track_id, 0) >= ALERT_COOLDOWN_SECONDS

                        if distance >= MOVEMENT_THRESHOLD_PX and cooldown_ok:
                            timestamp = datetime.now().isoformat(timespec="seconds")
                            writer.writerow([
                                timestamp,
                                zone,
                                "Position change",
                                "Requires human review; not evidence of misconduct",
                            ])
                            report.flush()
                            last_alert[track_id] = now

                    previous_positions[track_id] = point
                    x1, y1, x2, y2 = map(int, box.xyxy[0].tolist())
                    cv2.rectangle(frame, (x1, y1), (x2, y2), (0, 200, 0), 2)
                    cv2.putText(frame, zone, (x1, max(20, y1 - 8)),
                                cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 200, 0), 1)

            cv2.imshow("ExamGuard AI - Review Demo", frame)
            if cv2.waitKey(1) & 0xFF == ord("q"):
                break

    cap.release()
    cv2.destroyAllWindows()
    print(f"Event log saved to: {REPORT_PATH}")


if __name__ == "__main__":
    main()
